<?php
session_start();
require 'connection.php';

$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';

if ($email && $password) {
    $stmt = $conn->prepare("SELECT * FROM registrationedu WHERE Email = ? AND Password = ?");
    $stmt->bind_param("ss", $email, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($user = $result->fetch_assoc()) {
        $_SESSION['user_id'] = $user['ID'];
        $_SESSION['role'] = $user['role'];  // 'student' or 'lecturer'

        // Redirect based on role
        if ($user['role'] === 'student') {
            header("Location: student_dashboard.php");
        } elseif ($user['role'] === 'lecturer') {
            header("Location: lecturer_dashboard.php");
        }
        exit;
    } else {
        echo "Invalid email or password.";
    }
    $stmt->close();
}
$conn->close();
?>
