<?php
session_start();
if ($_SESSION['role'] !== 'lecturer') {
    header("Location: login.php");
    exit;
}
echo "Welcome to the Student Dashboard!";
?>
