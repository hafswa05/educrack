<!DOCTYPE html>
<html>
<head>
    <title> Educrack </title> 
    <link rel="stylesheet" href="reg.css">
    
</head>
<body>
    <form action="process_register.php" method="post">
      <input type="text" name="name" placeholder="Full Name" required>
      <input type="email" name="email" placeholder="Email" required>
      <input type="password" name="password" placeholder="Password" required>
      
      <select name ="role" required>
        <option value="student">Student</option>
        <option value="teacher">Teacher</option>
        </select>
      <button type="submit">Register</button>
    <h1 class="edu" id="edu1"> Welcome to Educrack</h1>
    
    <section>
        <h2> Login </h2>
        <fieldset>
            <legend> </legend>
            <label for="name">
                <span>Name: </span>
                <strong><span aria-label="required">*</span></strong>
              </label>
              <input type="text" id="name" name="name" required />
            </p>
            <p>
              <label for="mail">
                <span>Email: </span>
                <strong><span aria-label="required">*</span></strong>
              </label>
              <input type="email" id="mail" name="email" required />
            </p>
            <p>
              <label for="pwd">
                <span>Password: </span>
                <strong><span aria-label="required">*</span></strong>
              </label>
              <input type="password" id="pwd" name="password" required />
            </p>
           
          </fieldset>
          <p>
            <section>
                <p>
                  <button type="submit" class="login-btn">Register</button>
                </p>
              
          </section>
          
</form>
        </body>
</html>

