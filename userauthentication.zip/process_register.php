<?php
// processes the registration form data and stores it in the database.
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    require 'connection.php';

    $name = $_POST['name'];
    $email = $_POST['email'];
    $password =password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash the password for security'';
    $role = $_POST['role'];


    if ($name && $email && $password) {
        $stmt = $conn->prepare("INSERT INTO registrationedu (Name, Email, Password,role) VALUES (?, ?, ?,?)");
        $stmt->bind_param("ssss", $name, $email, $password, $role);
        $stmt->execute();
        echo "Registration successful. You can now <a href='login.php'>login</a>.";
        $stmt->close();
    } else {
        echo "Please fill in all required fields.";
    }

    $conn->close();
} else {
    echo "Invalid request.";
}
?>
