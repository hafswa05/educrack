<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['lec_id'])) {
  header("Location: login.php");
  exit;
}

$lec_id = $_SESSION['lec_id'];

$stmt = $pdo->prepare("
  SELECT n.title, n.content, n.unit_id, u.unit_name, n.is_summary, n.created_at 
  FROM notes n 
  JOIN units u ON u.unit_id = n.unit_id 
  WHERE n.lec_id = ?
  ORDER BY n.created_at DESC
");
$stmt->execute([$lec_id]);
$notes = $stmt->fetchAll();
?>

<h2>📄 Uploaded Notes</h2>
<?php foreach ($notes as $note): ?>
  <div style="border:1px solid #ccc; padding:15px; margin:10px 0;">
    <h3><?= htmlspecialchars($note['title']) ?> <?= $note['is_summary'] ? '(Summary)' : '' ?></h3>
    <small>Unit: <?= $note['unit_name'] ?> (<?= $note['unit_id'] ?>)</small><br>
    <small>Uploaded: <?= $note['created_at'] ?></small>
    <p><?= nl2br(htmlspecialchars($note['content'])) ?></p>
  </div>
<?php endforeach; ?>
