<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['lec_id'])) {
  die("Access denied.");
}
$lec_id = $_SESSION['lec_id'];

$stmt = $pdo->prepare("SELECT name, email FROM lecturers WHERE lec_id = ?");
$stmt->execute([$lec_id]);
$lecturer = $stmt->fetch();

// Total units taught
$unit_stmt = $pdo->prepare("
  SELECT COUNT(DISTINCT unit_id) FROM questions WHERE lec_id = ?
");
$unit_stmt->execute([$lec_id]);
$total_units = $unit_stmt->fetchColumn();

// Total questions added
$question_stmt = $pdo->prepare("
  SELECT COUNT(*) FROM questions WHERE lec_id = ?
");
$question_stmt->execute([$lec_id]);
$total_questions = $question_stmt->fetchColumn();
?>

<h2>👤 Lecturer Profile</h2>
<p><strong>Name:</strong> <?= htmlspecialchars($lecturer['name']) ?></p>
<p><strong>Email:</strong> <?= htmlspecialchars($lecturer['email']) ?></p>
<hr>
<h3>📌 Contribution</h3>
<ul>
  <li>Units Taught: <?= $total_units ?></li>
  <li>Questions Created: <?= $total_questions ?></li>
</ul>
