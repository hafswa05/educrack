<?php
session_start();
require_once 'db.php'; // your PDO config

// Ensure lecturer is logged in
if (!isset($_SESSION['lec_id'])) {
    header("Location: login.php");
    exit;
}

$lec_id = $_SESSION['lec_id'];

// Fetch units that this lecturer has added questions for
$stmt = $pdo->prepare("
    SELECT DISTINCT u.unit_id, u.unit_name
    FROM questions q
    JOIN units u ON q.unit_id = u.unit_id
    WHERE q.lec_id = ?
");
$stmt->execute([$lec_id]);
$units = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>📚 My Units</h2>
<ul>
<?php foreach ($units as $unit): ?>
    <li><?= htmlspecialchars($unit['unit_id']) ?> – <?= htmlspecialchars($unit['unit_name']) ?></li>
<?php endforeach; ?>
</ul>
