<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['lec_id'])) {
  die("Unauthorized. Please log in.");
}
$lec_id = $_SESSION['lec_id'];

// 1. Most failed questions
$failed_stmt = $pdo->prepare("
  SELECT q.question_text, COUNT(*) AS wrong_count
  FROM answers a
  JOIN questions q ON q.question_id = a.question_id
  WHERE a.iscorrect = 0 AND q.lec_id = ?
  GROUP BY a.question_id
  ORDER BY wrong_count DESC
  LIMIT 5
");
$failed_stmt->execute([$lec_id]);
$failed_questions = $failed_stmt->fetchAll();

// 2. Average score per quiz
$avg_stmt = $pdo->prepare("
  SELECT q.quiz_name, ROUND(AVG(h.score), 2) AS avg_score
  FROM history h
  JOIN quizzes q ON h.quiz_id = q.quiz_id
  WHERE q.lec_id = ?
  GROUP BY q.quiz_id
");
$avg_stmt->execute([$lec_id]);
$avg_scores = $avg_stmt->fetchAll();
?>

<h2>📊 Quiz Performance Analytics</h2>

<h3>❌ Top 5 Most Failed Questions</h3>
<ul>
  <?php foreach ($failed_questions as $q): ?>
    <li><?= htmlspecialchars($q['question_text']) ?> — <strong><?= $q['wrong_count'] ?> errors</strong></li>
  <?php endforeach; ?>
</ul>

<h3>📈 Average Score Per Quiz</h3>
<table border="1" cellpadding="10">
  <tr><th>Quiz</th><th>Average Score</th></tr>
  <?php foreach ($avg_scores as $row): ?>
    <tr>
      <td><?= htmlspecialchars($row['quiz_name']) ?></td>
      <td><?= $row['avg_score'] ?></td>
    </tr>
  <?php endforeach; ?>
</table>

<!-- For real analytics, consider feeding this data to Chart.js or Google Charts via JavaScript -->
