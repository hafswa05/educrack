<?php
$page_title = "Student Dashboard";
include 'partials/header.php';
check_auth('STUDENT');

$search_term = $_GET['search'] ?? '';

// Fetch available quizzes
$quizzes = [];
$sql = "SELECT q.id, q.title, q.course_name, q.duration_minutes, u.full_name as lecturer_name, 
        (SELECT COUNT(*) FROM questions WHERE quiz_id = q.id) as question_count
        FROM quizzes q
        JOIN users u ON q.lecturer_id = u.id
        WHERE q.title LIKE ? OR q.course_name LIKE ?
        ORDER BY q.created_at DESC";

if ($stmt = mysqli_prepare($conn, $sql)) {
    $param_search = "%" . $search_term . "%";
    mysqli_stmt_bind_param($stmt, "ss", $param_search, $param_search);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $quizzes[] = $row;
    }
    mysqli_stmt_close($stmt);
}
?>

<div class="page-box">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['user']['full_name']); ?>!</h2>
    <p>Below are the available quizzes. Select one to begin.</p>

    <form method="GET" action="dashboard_student.php" class="form-group" style="max-width: 400px; margin-bottom: 30px;">
        <input type="text" name="search" placeholder="Search by title or course..."
            value="<?php echo htmlspecialchars($search_term); ?>">
        <button type="submit" class="btn" style="width: auto; margin-top: 10px;">Search</button>
    </form>

    <h3>Available Quizzes</h3>
    <?php if (empty($quizzes)): ?>
        <p>No quizzes found.</p>
    <?php else: ?>
        <div class="quiz-grid">
            <?php foreach ($quizzes as $quiz): ?>
                <div class="quiz-card">
                    <h3><?php echo htmlspecialchars($quiz['title']); ?></h3>
                    <p><strong>Course:</strong> <?php echo htmlspecialchars($quiz['course_name']); ?></p>
                    <p><strong>By:</strong> <?php echo htmlspecialchars($quiz['lecturer_name']); ?></p>
                    <p><strong>Questions:</strong> <?php echo $quiz['question_count']; ?></p>
                    <p><strong>Time:</strong>
                        <?php echo $quiz['duration_minutes'] ? $quiz['duration_minutes'] . ' mins' : 'No time limit'; ?></p>
                    <a href="take_quiz.php?id=<?php echo $quiz['id']; ?>" class="btn">Start Quiz</a>
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'partials/footer.php'; ?>