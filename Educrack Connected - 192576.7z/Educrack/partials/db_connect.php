<?php
// Start session on all pages
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// Database credentials
define('DB_SERVER', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', ''); // Default XAMPP password is empty
define('DB_NAME', 'educrack_db');

// Attempt to connect to MySQL database
$conn = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);

// Check connection
if ($conn === false) {
    die("ERROR: Could not connect. " . mysqli_connect_error());
}

// Helper function to check if a user is logged in and has the correct role
function check_auth($role)
{
    if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== $role) {
        header("location: /educrack/index.php");
        exit;
    }
}
?>