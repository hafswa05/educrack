</main>
<footer>
    <div class="container">
        <p>© <?php echo date('Y'); ?> EDUCRACK. All Rights Reserved.</p>
    </div>
</footer>
</body>

</html>