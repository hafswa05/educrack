<?php require_once 'db_connect.php'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title ?? 'EDUCRACK'; ?></title>
    <link rel="stylesheet" href="/educrack/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600;700&display=swap" rel="stylesheet">
</head>

<body>
    <nav class="navbar">
        <div class="container">
            <a href="/educrack/index.php" class="logo">EDUCRACK</a>
            <ul class="nav-links">
                <?php if (isset($_SESSION['user'])): ?>
                    <?php if ($_SESSION['user']['role'] === 'LECTURER'): ?>
                        <li><a href="/educrack/dashboard_lecturer.php">Dashboard</a></li>
                        <li><a href="/educrack/create_quiz.php">Create Quiz</a></li>
                    <?php else: ?>
                        <li><a href="/educrack/dashboard_student.php">Dashboard</a></li>
                        <li><a href="/educrack/history.php">My History</a></li>
                    <?php endif; ?>
                    <li><a href="/educrack/logout.php" class="btn-logout">Logout</a></li>
                <?php else: ?>
                    <li><a href="/educrack/index.php">Login</a></li>
                    <li><a href="/educrack/register.php">Register</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
    <main class="container"></main>