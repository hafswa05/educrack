<?php
$page_title = "My Quiz History";
include 'partials/header.php';
check_auth('STUDENT');

$student_id = $_SESSION['user']['id'];

// Fetch attempt history
$history_sql = "
    SELECT a.id, q.title, a.score, a.total_questions, a.submitted_at
    FROM attempts a
    JOIN quizzes q ON a.quiz_id = q.id
    WHERE a.student_id = ?
    ORDER BY a.submitted_at DESC
";
$stmt = mysqli_prepare($conn, $history_sql);
mysqli_stmt_bind_param($stmt, "i", $student_id);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$history = mysqli_fetch_all($result, MYSQLI_ASSOC);
?>

<div class="page-box">
    <h2>My Quiz History</h2>
    <?php if (empty($history)): ?>
        <p>You have not attempted any quizzes yet.</p>
    <?php else: ?>
        <table class="data-table">
            <thead>
                <tr>
                    <th>Quiz Title</th>
                    <th>Date Taken</th>
                    <th>Score</th>
                    <th>Percentage</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($history as $item): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($item['title']); ?></td>
                        <td><?php echo date('F j, Y, g:i a', strtotime($item['submitted_at'])); ?></td>
                        <td><?php echo $item['score']; ?> / <?php echo $item['total_questions']; ?></td>
                        <td><?php echo ($item['total_questions'] > 0) ? round(($item['score'] / $item['total_questions']) * 100) : 0; ?>%
                        </td>
                        <td><a href="results.php?attempt_id=<?php echo $item['id']; ?>" class="btn btn-secondary"
                                style="width: auto; padding: 5px 10px;">View Results</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>
</div>

<?php include 'partials/footer.php'; ?>