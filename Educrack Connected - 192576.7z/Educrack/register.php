<?php
require_once 'partials/db_connect.php';

$full_name = $email = $password = $role = $student_number = "";
$errors = [];

// Redirect if already logged in
if (isset($_SESSION['user'])) {
    header("location: index.php");
    exit;
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Validate and sanitize inputs
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $role = trim($_POST['role']);
    $student_number = ($role === 'STUDENT') ? trim($_POST['student_number']) : null;

    if (empty($full_name))
        $errors[] = "Full name is required.";
    if (empty($email) || !filter_var($email, FILTER_VALIDATE_EMAIL))
        $errors[] = "A valid email is required.";
    if (empty($password) || strlen($password) < 6)
        $errors[] = "Password must be at least 6 characters long.";
    if (empty($role))
        $errors[] = "Please select a role.";
    if ($role === 'STUDENT' && empty($student_number))
        $errors[] = "Student Number is required for students.";

    // Check if email already exists
    $sql = "SELECT id FROM users WHERE email = ?";
    if ($stmt = mysqli_prepare($conn, $sql)) {
        mysqli_stmt_bind_param($stmt, "s", $email);
        mysqli_stmt_execute($stmt);
        mysqli_stmt_store_result($stmt);
        if (mysqli_stmt_num_rows($stmt) > 0) {
            $errors[] = "This email is already registered.";
        }
        mysqli_stmt_close($stmt);
    }

    if (empty($errors)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql = "INSERT INTO users (full_name, email, password, role, student_number) VALUES (?, ?, ?, ?, ?)";

        if ($stmt = mysqli_prepare($conn, $sql)) {
            mysqli_stmt_bind_param($stmt, "sssss", $full_name, $email, $hashed_password, $role, $student_number);
            if (mysqli_stmt_execute($stmt)) {
                // Registration successful, log the user in automatically
                $user_id = mysqli_insert_id($conn);
                $_SESSION['user'] = [
                    'id' => $user_id,
                    'full_name' => $full_name,
                    'email' => $email,
                    'role' => $role
                ];
                header("location: index.php"); // Redirect will handle routing to correct dashboard
                exit;
            } else {
                $errors[] = "Something went wrong. Please try again later.";
            }
            mysqli_stmt_close($stmt);
        }
    }
    mysqli_close($conn);
}

$page_title = "Register";
include 'partials/header.php';
?>
<div class="form-container">
    <h2>Create an Account</h2>
    <?php if (!empty($errors)): ?>
        <div class="alert alert-danger">
            <?php foreach ($errors as $error): ?>
                <p><?php echo $error; ?></p>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
    <form action="register.php" method="post" id="register-form">
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <div class="form-group">
            <label>I am a...</label>
            <select name="role" id="role-select" required>
                <option value="">-- Select a Role --</option>
                <option value="STUDENT">Student</option>
                <option value="LECTURER">Lecturer</option>
            </select>
        </div>
        <div class="form-group" id="student-number-group" style="display: none;">
            <label>Student Number</label>
            <input type="text" name="student_number">
        </div>
        <div class="form-group">
            <input type="submit" class="btn" value="Register">
        </div>
        <p>Already have an account? <a href="index.php">Login here</a>.</p>
    </form>
</div>

<script>
    document.getElementById('role-select').addEventListener('change', function () {
        var studentNumberGroup = document.getElementById('student-number-group');
        if (this.value === 'STUDENT') {
            studentNumberGroup.style.display = 'block';
            studentNumberGroup.querySelector('input').required = true;
        } else {
            studentNumberGroup.style.display = 'none';
            studentNumberGroup.querySelector('input').required = false;
        }
    });
</script>

<?php include 'partials/footer.php'; ?>