<?php
require_once 'partials/db_connect.php';
check_auth('STUDENT');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = $_SESSION['user']['id'];
    $quiz_id = $_POST['quiz_id'];
    $answers = $_POST['answers'] ?? []; // student's selected option_ids

    // Get correct answers from DB
    $sql = "SELECT q.id as question_id, o.id as correct_option_id
            FROM questions q 
            JOIN options o ON q.id = o.question_id
            WHERE q.quiz_id = ? AND o.is_correct = 1";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $quiz_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    $correct_answers = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $correct_answers[$row['question_id']] = $row['correct_option_id'];
    }

    $score = 0;
    $total_questions = count($correct_answers);

    // Start transaction
    mysqli_begin_transaction($conn);
    try {
        // 1. Create the attempt record
        $sql_attempt = "INSERT INTO attempts (student_id, quiz_id, score, total_questions) VALUES (?, ?, ?, ?)";
        $stmt_attempt = mysqli_prepare($conn, $sql_attempt);
        // We will update score later
        mysqli_stmt_bind_param($stmt_attempt, "iiii", $student_id, $quiz_id, $score, $total_questions);
        mysqli_stmt_execute($stmt_attempt);
        $attempt_id = mysqli_insert_id($conn);

        // 2. Log each answer and calculate score
        $sql_answer = "INSERT INTO attempt_answers (attempt_id, question_id, selected_option_id, is_correct) VALUES (?, ?, ?, ?)";
        $stmt_answer = mysqli_prepare($conn, $sql_answer);

        foreach ($correct_answers as $question_id => $correct_option_id) {
            $selected_option_id = $answers[array_search($question_id, array_keys($answers))] ?? 0; // Find selected answer
            $is_correct_answer = ($selected_option_id == $correct_option_id);
            if ($is_correct_answer) {
                $score++;
            }
            mysqli_stmt_bind_param($stmt_answer, "iiii", $attempt_id, $question_id, $selected_option_id, $is_correct_answer);
            mysqli_stmt_execute($stmt_answer);
        }

        // 3. Update the score in the attempts table
        $sql_update_score = "UPDATE attempts SET score = ? WHERE id = ?";
        $stmt_update = mysqli_prepare($conn, $sql_update_score);
        mysqli_stmt_bind_param($stmt_update, "ii", $score, $attempt_id);
        mysqli_stmt_execute($stmt_update);

        mysqli_commit($conn);

        // Redirect to results page
        header("location: results.php?attempt_id=" . $attempt_id);
        exit;

    } catch (Exception $e) {
        mysqli_rollback($conn);
        die("Error processing quiz. Please try again. " . $e->getMessage());
    }

} else {
    header("location: dashboard_student.php");
    exit;
}