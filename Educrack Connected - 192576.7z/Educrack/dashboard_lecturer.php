<?php
$page_title = "Lecturer Dashboard";
include 'partials/header.php';
check_auth('LECTURER');

$lecturer_id = $_SESSION['user']['id'];

// Fetch quizzes created by this lecturer
$quizzes = [];
$sql = "SELECT id, title, course_name, (SELECT COUNT(*) FROM questions WHERE quiz_id = quizzes.id) as question_count FROM quizzes WHERE lecturer_id = ? ORDER BY created_at DESC";
if ($stmt = mysqli_prepare($conn, $sql)) {
    mysqli_stmt_bind_param($stmt, "i", $lecturer_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    while ($row = mysqli_fetch_assoc($result)) {
        $quizzes[] = $row;
    }
    mysqli_stmt_close($stmt);
}
?>

<div class="page-box">
    <h2>Welcome, <?php echo htmlspecialchars($_SESSION['user']['full_name']); ?>!</h2>
    <p>Here are the quizzes you have created. You can create a new one at any time.</p>
    <a href="create_quiz.php" class="btn" style="margin-bottom: 20px; display: inline-block; width: auto;">+ Create New
        Quiz</a>

    <h3>Your Quizzes</h3>
    <?php if (empty($quizzes)): ?>
        <p>You haven't created any quizzes yet.</p>
    <?php else: ?>
        <div class="quiz-grid">
            <?php foreach ($quizzes as $quiz): ?>
                <div class="quiz-card">
                    <h3><?php echo htmlspecialchars($quiz['title']); ?></h3>
                    <p><strong>Course:</strong> <?php echo htmlspecialchars($quiz['course_name']); ?></p>
                    <p><strong>Questions:</strong> <?php echo $quiz['question_count']; ?></p>
                    <!-- Add edit/delete functionality here if needed -->
                </div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>
</div>

<?php include 'partials/footer.php'; ?>