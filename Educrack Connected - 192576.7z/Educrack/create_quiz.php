<?php
$page_title = "Create a New Quiz";
include 'partials/header.php';
check_auth('LECTURER');
?>

<div class="page-box">
    <h2>Build a New Quiz</h2>
    <p>Fill in the quiz details, then add questions one by one.</p>

    <form id="quiz-form">
        <!-- Quiz Details -->
        <fieldset>
            <legend>
                <h3>Step 1: Quiz Details</h3>
            </legend>
            <div class="form-group">
                <label for="title">Quiz Title</label>
                <input type="text" id="title" name="title" required>
            </div>
            <div class="form-group">
                <label for="course_name">Course Name</label>
                <input type="text" id="course_name" name="course_name" required>
            </div>
            <div class="form-group">
                <label for="duration">Duration (in minutes, optional)</label>
                <input type="number" id="duration" name="duration" min="1">
            </div>
        </fieldset>

        <!-- Add Question Form -->
        <fieldset>
            <legend>
                <h3>Step 2: Add Questions</h3>
            </legend>
            <div class="form-group">
                <label for="question_text">Question</label>
                <input type="text" id="question_text" placeholder="Enter the question text">
            </div>
            <div class="form-group">
                <label>Options (Select the correct answer)</label>
                <div style="display: flex; align-items: center; margin-bottom: 10px;">
                    <input type="radio" name="correct_answer" value="0" checked style="width: auto;">
                    <input type="text" class="option-input" placeholder="Option 1">
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 10px;">
                    <input type="radio" name="correct_answer" value="1" style="width: auto;">
                    <input type="text" class="option-input" placeholder="Option 2">
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 10px;">
                    <input type="radio" name="correct_answer" value="2" style="width: auto;">
                    <input type="text" class="option-input" placeholder="Option 3">
                </div>
                <div style="display: flex; align-items: center; margin-bottom: 10px;">
                    <input type="radio" name="correct_answer" value="3" style="width: auto;">
                    <input type="text" class="option-input" placeholder="Option 4">
                </div>
            </div>
            <button type="button" id="add-question-btn" class="btn btn-secondary">Add Question to Quiz</button>
        </fieldset>
    </form>

    <!-- Live Preview of Questions -->
    <div id="questions-preview" style="margin-top: 30px;">
        <h3>Added Questions</h3>
        <div id="questions-list">
            <!-- Questions will be added here by JavaScript -->
        </div>
    </div>

    <!-- Final Save Button -->
    <button id="save-quiz-btn" class="btn" style="margin-top: 30px;">Save Final Quiz</button>
    <div id="form-status" style="margin-top: 15px;"></div>
</div>

<script src="/educrack/js/quiz_builder.js"></script>
<?php include 'partials/footer.php'; ?>