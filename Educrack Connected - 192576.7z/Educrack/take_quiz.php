<?php
$page_title = "Take Quiz";
include 'partials/header.php';
check_auth('STUDENT');

$quiz_id = $_GET['id'] ?? 0;
if (!$quiz_id) {
    header("location: dashboard_student.php");
    exit;
}

// Fetch quiz and questions data
$quiz_sql = "SELECT title, duration_minutes FROM quizzes WHERE id = ?";
$quiz_stmt = mysqli_prepare($conn, $quiz_sql);
mysqli_stmt_bind_param($quiz_stmt, "i", $quiz_id);
mysqli_stmt_execute($quiz_stmt);
$quiz_result = mysqli_stmt_get_result($quiz_stmt);
$quiz = mysqli_fetch_assoc($quiz_result);

if (!$quiz) {
    echo "<p>Quiz not found.</p>";
    include 'partials/footer.php';
    exit;
}

$questions_sql = "
    SELECT q.id as question_id, q.question_text, o.id as option_id, o.option_text
    FROM questions q
    JOIN options o ON q.id = o.question_id
    WHERE q.quiz_id = ?
    ORDER BY q.id, o.id
";
$questions_stmt = mysqli_prepare($conn, $questions_sql);
mysqli_stmt_bind_param($questions_stmt, "i", $quiz_id);
mysqli_stmt_execute($questions_stmt);
$questions_result = mysqli_stmt_get_result($questions_stmt);

$quiz_data = [];
while ($row = mysqli_fetch_assoc($questions_result)) {
    $quiz_data[$row['question_id']]['question_text'] = $row['question_text'];
    $quiz_data[$row['question_id']]['options'][] = [
        'id' => $row['option_id'],
        'text' => $row['option_text']
    ];
}
// Re-index array for JavaScript
$quiz_data = array_values($quiz_data);
?>

<div class="page-box">
    <form id="quiz-form-taker" action="submit_quiz.php" method="POST">
        <input type="hidden" name="quiz_id" value="<?php echo $quiz_id; ?>">

        <div class="quiz-header">
            <h2><?php echo htmlspecialchars($quiz['title']); ?></h2>
            <?php if ($quiz['duration_minutes']): ?>
                <div class="timer" id="timer">Time Left: <?php echo $quiz['duration_minutes']; ?>:00</div>
            <?php endif; ?>
        </div>

        <div class="progress-bar">
            <div class="progress-bar-fill" id="progress-bar-fill"></div>
        </div>

        <div id="question-container">
            <!-- Questions will be loaded by JS -->
        </div>

        <button type="button" id="next-btn" class="btn" style="margin-top: 20px;">Next Question</button>
    </form>
</div>

<!-- Pass PHP data to JavaScript -->
<script>
    const quizData = <?php echo json_encode($quiz_data); ?>;
    const duration = <?php echo $quiz['duration_minutes'] ?? 'null'; ?>;
</script>
<script src="/educrack/js/quiz_taker.js"></script>

<?php include 'partials/footer.php'; ?>