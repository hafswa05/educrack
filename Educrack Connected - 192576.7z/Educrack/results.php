<?php
$page_title = "Quiz Results";
include 'partials/header.php';
check_auth('STUDENT');

$attempt_id = $_GET['attempt_id'] ?? 0;
if (!$attempt_id) {
    header("location: dashboard_student.php");
    exit;
}

// Fetch attempt details
$sql = "SELECT a.score, a.total_questions, q.title 
        FROM attempts a 
        JOIN quizzes q ON a.quiz_id = q.id 
        WHERE a.id = ? AND a.student_id = ?";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_bind_param($stmt, "ii", $attempt_id, $_SESSION['user']['id']);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);
$attempt = mysqli_fetch_assoc($result);

if (!$attempt) {
    echo "Attempt not found.";
    include 'partials/footer.php';
    exit;
}

$percentage = ($attempt['total_questions'] > 0) ? round(($attempt['score'] / $attempt['total_questions']) * 100) : 0;

// Fetch detailed review data
$review_sql = "
    SELECT 
        q.question_text, 
        aa.is_correct,
        so.option_text as selected_option,
        co.option_text as correct_option
    FROM attempt_answers aa
    JOIN questions q ON aa.question_id = q.id
    JOIN options so ON aa.selected_option_id = so.id
    JOIN options co ON (q.id = co.question_id AND co.is_correct = 1)
    WHERE aa.attempt_id = ?
";
$stmt_review = mysqli_prepare($conn, $review_sql);
mysqli_stmt_bind_param($stmt_review, "i", $attempt_id);
mysqli_stmt_execute($stmt_review);
$review_result = mysqli_stmt_get_result($stmt_review);
$review_data = mysqli_fetch_all($review_result, MYSQLI_ASSOC);
?>

<div class="page-box">
    <div class="result-summary">
        <h2>Results for: <?php echo htmlspecialchars($attempt['title']); ?></h2>
        <h1>Your Score: <?php echo $attempt['score']; ?> / <?php echo $attempt['total_questions']; ?>
            (<?php echo $percentage; ?>%)</h1>
    </div>

    <h3>Question by Question Review</h3>
    <?php foreach ($review_data as $item): ?>
        <div class="result-question <?php echo $item['is_correct'] ? 'correct' : 'incorrect'; ?>">
            <p><strong><?php echo htmlspecialchars($item['question_text']); ?></strong></p>
            <p>Your Answer: <?php echo htmlspecialchars($item['selected_option']); ?></p>
            <?php if (!$item['is_correct']): ?>
                <p class="correct-answer-label">Correct Answer: <?php echo htmlspecialchars($item['correct_option']); ?></p>
            <?php endif; ?>
        </div>
    <?php endforeach; ?>

    <a href="dashboard_student.php" class="btn" style="margin-top: 20px;">Back to Dashboard</a>
</div>

<?php include 'partials/footer.php'; ?>