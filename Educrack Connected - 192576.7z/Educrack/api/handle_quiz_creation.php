<?php
header('Content-Type: application/json');
require_once '../partials/db_connect.php';

// Only allow logged-in lecturers
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'LECTURER') {
    echo json_encode(['success' => false, 'message' => 'Unauthorized']);
    exit;
}

$lecturer_id = $_SESSION['user']['id'];
$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['success' => false, 'message' => 'Invalid data received.']);
    exit;
}

$title = $data['title'];
$course_name = $data['course_name'];
$duration = $data['duration_minutes'];
$questions = $data['questions'];

mysqli_begin_transaction($conn);

try {
    // 1. Insert the quiz
    $sql_quiz = "INSERT INTO quizzes (lecturer_id, title, course_name, duration_minutes) VALUES (?, ?, ?, ?)";
    $stmt_quiz = mysqli_prepare($conn, $sql_quiz);
    mysqli_stmt_bind_param($stmt_quiz, "issi", $lecturer_id, $title, $course_name, $duration);
    mysqli_stmt_execute($stmt_quiz);
    $quiz_id = mysqli_insert_id($conn);
    mysqli_stmt_close($stmt_quiz);

    if (!$quiz_id) {
        throw new Exception("Failed to create quiz.");
    }

    // 2. Insert questions and options
    $sql_question = "INSERT INTO questions (quiz_id, question_text) VALUES (?, ?)";
    $sql_option = "INSERT INTO options (question_id, option_text, is_correct) VALUES (?, ?, ?)";

    $stmt_question = mysqli_prepare($conn, $sql_question);
    $stmt_option = mysqli_prepare($conn, $sql_option);

    foreach ($questions as $q) {
        // Insert question
        mysqli_stmt_bind_param($stmt_question, "is", $quiz_id, $q['text']);
        mysqli_stmt_execute($stmt_question);
        $question_id = mysqli_insert_id($conn);

        if (!$question_id) {
            throw new Exception("Failed to create question.");
        }

        // Insert options
        foreach ($q['options'] as $i => $opt) {
            $is_correct = ($i == $q['correct']);
            mysqli_stmt_bind_param($stmt_option, "isi", $question_id, $opt, $is_correct);
            mysqli_stmt_execute($stmt_option);
        }
    }

    mysqli_stmt_close($stmt_question);
    mysqli_stmt_close($stmt_option);

    mysqli_commit($conn);
    echo json_encode(['success' => true, 'quiz_id' => $quiz_id]);

} catch (Exception $e) {
    mysqli_rollback($conn);
    echo json_encode(['success' => false, 'message' => $e->getMessage()]);
}

mysqli_close($conn);
?>