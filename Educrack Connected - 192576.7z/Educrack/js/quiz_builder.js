document.addEventListener('DOMContentLoaded', function() {
    const addQuestionBtn = document.getElementById('add-question-btn');
    const saveQuizBtn = document.getElementById('save-quiz-btn');
    const questionsList = document.getElementById('questions-list');
    
    let questionsData = [];
    let questionCounter = 0;

    addQuestionBtn.addEventListener('click', () => {
        const questionText = document.getElementById('question_text').value.trim();
        const optionInputs = document.querySelectorAll('.option-input');
        const correctOptionIndex = document.querySelector('input[name="correct_answer"]:checked').value;

        const options = Array.from(optionInputs).map(input => input.value.trim());

        // Validation
        if (!questionText) {
            alert('Please enter a question.');
            return;
        }
        if (options.some(opt => opt === '')) {
            alert('Please fill in all four options.');
            return;
        }

        const question = {
            id: questionCounter++,
            text: questionText,
            options: options,
            correct: parseInt(correctOptionIndex)
        };

        questionsData.push(question);
        renderQuestion(question);

        // Clear input fields
        document.getElementById('question_text').value = '';
        optionInputs.forEach(input => input.value = '');
        document.querySelector('input[name="correct_answer"][value="0"]').checked = true;
    });

    function renderQuestion(question) {
        const item = document.createElement('div');
        item.className = 'question-item';
        item.dataset.id = question.id;
        item.innerHTML = `
            <p><strong>Q: ${question.text}</strong></p>
            <ul>
                ${question.options.map((opt, i) => `<li ${i === question.correct ? 'style="font-weight:bold; color: #2ecc71;"' : ''}>${opt}</li>`).join('')}
            </ul>
            <button class="btn-delete-question">Delete</button>
        `;
        questionsList.appendChild(item);

        item.querySelector('.btn-delete-question').addEventListener('click', () => {
            questionsData = questionsData.filter(q => q.id !== question.id);
            item.remove();
        });
    }
    
    saveQuizBtn.addEventListener('click', async () => {
        const title = document.getElementById('title').value.trim();
        const courseName = document.getElementById('course_name').value.trim();
        const duration = document.getElementById('duration').value;

        if (!title || !courseName) {
            alert('Please fill in the Quiz Title and Course Name.');
            return;
        }
        if (questionsData.length === 0) {
            alert('Please add at least one question to the quiz.');
            return;
        }

        const quizData = {
            title: title,
            course_name: courseName,
            duration_minutes: duration || null,
            questions: questionsData
        };
        
        const statusDiv = document.getElementById('form-status');
        statusDiv.textContent = 'Saving...';
        
        try {
            const response = await fetch('/educrack/api/handle_quiz_creation.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(quizData)
            });

            const result = await response.json();

            if (result.success) {
                statusDiv.style.color = 'var(--success-color)';
                statusDiv.textContent = 'Quiz saved successfully! Redirecting...';
                setTimeout(() => {
                    window.location.href = '/educrack/dashboard_lecturer.php';
                }, 2000);
            } else {
                throw new Error(result.message || 'Failed to save quiz.');
            }
        } catch (error) {
            statusDiv.style.color = 'var(--error-color)';
            statusDiv.textContent = 'Error: ' + error.message;
        }
    });
});