document.addEventListener('DOMContentLoaded', () => {
    const questionContainer = document.getElementById('question-container');
    const nextBtn = document.getElementById('next-btn');
    const progressBar = document.getElementById('progress-bar-fill');
    const quizForm = document.getElementById('quiz-form-taker');
    const timerEl = document.getElementById('timer');

    let currentQuestionIndex = 0;

    function renderQuestion(index) {
        const question = quizData[index];
        questionContainer.innerHTML = `
            <h3>Q${index + 1}: ${question.question_text}</h3>
            <div class="options-container">
                ${question.options.map(opt => `
                    <label class="option-label">
                        <input type="radio" name="answers[${index}]" value="${opt.id}" required>
                        ${opt.text}
                    </label>
                `).join('')}
            </div>
        `;

        // Update progress bar
        progressBar.style.width = `${((index + 1) / quizData.length) * 100}%`;

        // Update button text
        if (index === quizData.length - 1) {
            nextBtn.textContent = 'Submit Quiz';
        } else {
            nextBtn.textContent = 'Next Question';
        }
    }

    nextBtn.addEventListener('click', () => {
        // Check if an answer is selected
        const selectedOption = questionContainer.querySelector('input[type="radio"]:checked');
        if (!selectedOption) {
            alert('Please select an answer before proceeding.');
            return;
        }

        if (currentQuestionIndex < quizData.length - 1) {
            currentQuestionIndex++;
            renderQuestion(currentQuestionIndex);
        } else {
            // Submit the form
            quizForm.submit();
        }
    });

    // Timer functionality
    if (duration) {
        let timeInSeconds = duration * 60;
        const timerInterval = setInterval(() => {
            timeInSeconds--;
            const minutes = Math.floor(timeInSeconds / 60);
            const seconds = timeInSeconds % 60;
            timerEl.textContent = `Time Left: ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;

            if (timeInSeconds <= 0) {
                clearInterval(timerInterval);
                alert('Time is up! Submitting your answers.');
                quizForm.submit();
            }
        }, 1000);
    }
    
    // Initial render
    renderQuestion(currentQuestionIndex);
});