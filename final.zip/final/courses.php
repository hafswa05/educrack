<?php
session_start();

// Redirect if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: loginStudent.php");
    exit;
}

$conn = new mysqli('localhost', 'root', '', 'educrack');
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$student_id = $_SESSION['student_id'];

// Get student’s course
$courseQuery = $conn->prepare("SELECT course_id FROM students WHERE student_id = ?");
$courseQuery->bind_param("i", $student_id);
$courseQuery->execute();
$courseResult = $courseQuery->get_result();
$student_course_id = $courseResult->fetch_assoc()['course_id'];

// Fetch course and units
$sql = "
  SELECT c.course_id, c.course_name, u.unit_id, u.unit_name
  FROM courses c
  LEFT JOIN units u ON c.course_id = u.course_id
  WHERE c.course_id = ?
  ORDER BY u.unit_name
";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $student_course_id);
$stmt->execute();
$result = $stmt->get_result();

// Group units by course
$units = [];
$course_name = '';
while ($row = $result->fetch_assoc()) {
    $course_name = $row['course_name'];
    $units[] = $row['unit_name'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>My Course Units</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background: #f8f9fa;
      padding: 30px;
    }
    .container {
      max-width: 800px;
      margin: auto;
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }
    h2 {
      color: #333;
      text-align: center;
    }
    details {
      margin: 20px 0;
      background: #f1f1f1;
      border-radius: 6px;
      padding: 10px;
    }
    summary {
      font-weight: bold;
      font-size: 18px;
      cursor: pointer;
    }
    ul {
      margin-top: 10px;
      padding-left: 20px;
    }
    li {
      padding: 6px 0;
    }
    .back-btn {
      display: inline-block;
      margin-top: 20px;
      text-decoration: none;
      color: #fff;
      background: #007bff;
      padding: 8px 16px;
      border-radius: 5px;
    }
    .back-btn:hover {
      background: #0056b3;
    }
  </style>
</head>
<body>
  <div class="container">
    <h2>My Course: <?= htmlspecialchars($course_name) ?></h2>

    <details open>
      <summary>Units under <?= htmlspecialchars($course_name) ?></summary>
      <ul>
        <?php foreach ($units as $unit): ?>
          <li><?= htmlspecialchars($unit) ?></li>
        <?php endforeach; ?>
      </ul>
    </details>

    <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
  </div>
</body>
</html>
