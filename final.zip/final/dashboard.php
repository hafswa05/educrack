<?php
session_start();

// Redirect to login if not logged in
if (!isset($_SESSION['student_id'])) {
    header("Location: login.php");
    exit;
}

// Database connection
$conn = new mysqli('localhost', 'root', '', 'educrack');
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$student_id = $_SESSION['student_id'];

// Fetch student details from database
$sql = "SELECT fullname, email FROM students WHERE student_id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $student_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
$student = $result->fetch_assoc();
$full_name = $student['fullname'];
$first_name = explode(' ', $full_name)[0]; // Use the first word as first name
$email = $student['email'];
} else {
$full_name = "Student";
$first_name = "Student";
$email = "";
}
// Get time-based personalized greeting
function getGreeting($name) {
    $hour = date('G');
    if ($hour < 12) {
        return "Good morning, <span class='highlight-name'>$name</span>! ☀️";
    } elseif ($hour < 17) {
        return "Good afternoon, <span class='highlight-name'>$name</span>! 🌤️";
    } else {
        return "Good evening, <span class='highlight-name'>$name</span>! 🌙";
    }
}

// Get quiz progress data
$quiz_count = $conn->query("SELECT COUNT(*) FROM quizzes")->fetch_row()[0];
$completed_quizzes_result = $conn->query("SELECT COUNT(*) FROM history WHERE student_id = $student_id");
$completed_quizzes = $completed_quizzes_result->fetch_row()[0];

$progress_percent = $quiz_count > 0 ? round(($completed_quizzes / $quiz_count) * 100) : 0;

?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Student Dashboard</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
  <style>
    :root {
      --primary: #147ae0;
      --secondary: #3d28c9;
      --highlight: #ffcc00;
      --light: #f8f9fa;
      --dark: #343a40;
    }
    
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
    }
    
    body {
      background-color: #f5f5f5;
      line-height: 1.6;
    }
    
    .dashboard {
      max-width: 1200px;
      margin: 0 auto;
      padding: 20px;
    }
    
    /* Welcome Header */
    .welcome-header {
      background: linear-gradient(135deg, var(--primary), var(--secondary));
      color: white;
      padding: 30px;
      border-radius: 12px;
      margin-bottom: 30px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      position: relative;
      overflow: hidden;
    }
    
    .welcome-header::after {
      content: "";
      position: absolute;
      top: -50%;
      right: -50%;
      width: 100%;
      height: 200%;
      background: radial-gradient(circle, rgba(255,255,255,0.1) 0%, rgba(255,255,255,0) 70%);
    }
    
    .welcome-title {
      font-size: 2.3rem;
      margin-bottom: 10px;
      font-weight: 600;
      line-height: 1.2;
      position: relative;
      z-index: 1;
    }
    
    .highlight-name {
      color: white;
      font-weight: 700;
      text-decoration: underline;
      text-decoration-color: var(--highlight);
      text-underline-offset: 4px;
      text-decoration-thickness: 3px;
      animation: pulse 2s infinite;
    }
    
    @keyframes pulse {
      0% { text-decoration-color: var(--highlight); }
      50% { text-decoration-color: rgba(255, 204, 0, 0.5); }
      100% { text-decoration-color: var(--highlight); }
    }
    
    .welcome-subtitle {
      font-size: 1.1rem;
      opacity: 0.9;
      margin-bottom: 15px;
      position: relative;
      z-index: 1;
    }
    
    .student-email {
      display: block;
      margin-bottom: 15px;
      font-size: 0.9rem;
      opacity: 0.8;
      position: relative;
      z-index: 1;
    }
    
    .todays-date {
      display: inline-block;
      background: rgba(255,255,255,0.15);
      padding: 5px 12px;
      border-radius: 20px;
      font-size: 0.9rem;
      margin-bottom: 15px;
      position: relative;
      z-index: 1;
    }
    
    .progress-container {
      margin-top: 20px;
      position: relative;
      z-index: 1;
    }
    
    .progress-bar {
      height: 6px;
      background: rgba(255,255,255,0.2);
      border-radius: 3px;
      margin-bottom: 5px;
    }
    
    .progress-fill {
      height: 100%;
      background: var(--highlight);
      border-radius: 3px;
      width: <?= $progress_percent ?>%;
      transition: width 0.5s ease;
    }
    
    .progress-text {
      font-size: 0.9rem;
      opacity: 0.9;
    }
    
    /* Dashboard Cards */
    .dashboard-cards {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 20px;
      margin-bottom: 30px;
    }
    
    .card {
      background: white;
      border-radius: 10px;
      padding: 20px;
      box-shadow: 0 2px 10px rgba(0,0,0,0.1);
      transition: all 0.3s ease;
      position: relative;
      overflow: hidden;
    }
    
    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 5px 15px rgba(0,0,0,0.1);
    }
    
    .card-icon {
      font-size: 2rem;
      color: var(--primary);
      margin-bottom: 15px;
    }
    
    .card h3 {
      color: var(--dark);
      margin-bottom: 10px;
    }
    
    .card p {
      color: #666;
      margin-bottom: 15px;
    }
    
    .card-btn {
      display: inline-block;
      background: var(--primary);
      color: white;
      padding: 8px 16px;
      border-radius: 5px;
      text-decoration: none;
      font-weight: 500;
      transition: all 0.3s;
    }
    
    .card-btn:hover {
      background: #0d6bb7;
      transform: translateY(-2px);
    }
    
    /* Responsive Design */
    @media (max-width: 768px) {
      .welcome-title {
        font-size: 1.8rem;
      }
      
      .dashboard-cards {
        grid-template-columns: 1fr;
      }
    }
  </style>
</head>
<body>
  <div class="dashboard">
    <!-- Personalized Welcome Section -->
    <div class="welcome-header">
      <h1 class="welcome-title"><?= getGreeting($first_name) ?></h1>
      <p class="welcome-subtitle">Welcome back to your learning dashboard</p>
      <span class="student-email"><i class="fas fa-envelope"></i> <?= htmlspecialchars($email) ?></span>
      <span class="todays-date">
        <i class="far fa-calendar-alt"></i> <?= date('l, F j, Y') ?>
      </span>
      
      <div class="progress-container">
        <div class="progress-bar">
          <div class="progress-fill"></div>
        </div>
        <div class="progress-text">
          Your progress: <?= $progress_percent ?>% complete (<?= $completed_quizzes ?> of <?= $quiz_count ?> quizzes)
        </div>
      </div>
    </div>

    <!-- Dashboard Cards -->
    <div class="dashboard-cards">
      <div class="card">
        <div class="card-icon">
          <i class="fas fa-book-open"></i>
        </div>
        <h3>My Courses</h3>
        <p>Access all your enrolled courses and learning materials.</p>
        <a href="courses.php" class="card-btn">View Courses</a>
      </div>
      
      <div class="card">
        <div class="card-icon">
          <i class="fas fa-question-circle"></i>
        </div>
        <h3>Quizzes</h3>
        <p>Test your knowledge and track your progress.</p>
        <a href="quizzes.php" class="card-btn">View Quizzes</a>
      </div>
      
      <div class="card">
        <div class="card-icon">
          <i class="fas fa-chart-line"></i>
        </div>
        <h3>Performance</h3>
        <p>See your results and improvement over time.</p>
        <a href="performance.php" class="card-btn">View Analytics</a>
      </div>
      
      <div class="card">
        <div class="card-icon">
          <i class="fas fa-sticky-note"></i>
        </div>
        <h3>My Notes</h3>
        <p>Review and manage your personal study notes.</p>
        <a href="notes.php" class="card-btn">View Notes</a>
      </div>
    </div>
  </div>
</body>
</html>
<?php
$conn->close();
?>