
    const quizzes = [
      { title: "Math Quiz: Algebra Basics", description: "Test your knowledge of basic algebra." },
      { title: "Science Quiz: The Solar System", description: "How well do you know the planets?" },
      { title: "History Quiz: World War II", description: "Important facts from 1939-1945." },
      { title: "Geography Quiz: Capital Cities", description: "Name the capital cities of countries." },
      { title: "English Quiz: Grammar Test", description: "Check your grammar skills." }
    ];

    function renderQuizzes(filteredQuizzes) {
      const quizList = document.getElementById("quizList");
      quizList.innerHTML = "";

      if (filteredQuizzes.length === 0) {
        quizList.innerHTML = "<p>No quizzes found.</p>";
        return;
      }

      filteredQuizzes.forEach(quiz => {
        const quizDiv = document.createElement("div");
        quizDiv.className = "quiz";
        quizDiv.innerHTML = `<h3>${quiz.title}</h3> <p>${quiz.description}</p>`;
        quizList.appendChild(quizDiv);
      });
    }

    function searchQuizzes() {
      const input = document.getElementById("search").value.toLowerCase();
      const filtered = quizzes.filter(q => q.title.toLowerCase().includes(input) || q.description.toLowerCase().includes(input));
      renderQuizzes(filtered);
    }
    renderQuizzes(quizzes);
